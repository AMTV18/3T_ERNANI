//CRIAR NOSSO SERVIDOR
const express = require("express");
const path = require("path");
const app = express();


//CRIAR ROTAS
app.get("/", function (req, res) {
  });

//
app.listen(333, function ()