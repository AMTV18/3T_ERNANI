// MTODOS DE ARRAY
const comidas = ['currasco, pizza']
comidas[3] = 'sushi' // MANUAL
comidas.push('berinjela') //EMPURRANDO VALOR PARA FINAL DA LISTA
console.log(comidas)